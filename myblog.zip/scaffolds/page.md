---
title: {{ title }}
date: {{ date }}
type: 
---
